ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

// text comes before first image.

1   TEXT  241  200  350   68    00000       05060       3     "�Who was this man?� I asked, �to threaten the Roman emperor?�"     0   0   0   
2   TEXT  206  100  450   200    05060      32648       3     "Titles such as �Emperor� meant nothing to Huns.  Attila was not an appointed ruler, only the strongest among the Huns.  The amenities of his �office� meant nothing to him.  While his chieftains and council ate off of silver plates, Attila�s own plate and goblet were hewn from simple wood.  His Scythian guards had jewels on their sword hilts and their cloaks were clasped with gold, but Attila showed no such affectations."     0   0   0   
3   TEXT  500  170  210   310    37709      26017       3     "He was interested only in conquest.  Some said that he was trying to build a legacy to rival that of Alexander the Great.  All of the barbarians wanted to possess Rome, as if it would buy them instant legitimacy as a world-spanning Empire.  Unlike most of the other barbarians, however, Attila was actually going to get his chance."     0   0   0  



4   PICT  164  262   400   400   05060    32648       0     ""                                 255 255 255 
5   PICT  103  075  400   400    37709    26017       1     ""                                 255 255 255 

17  SND   0    0    0     0     4         00000       0     "xc1s3end.mp3"                        0   0   0 
18  WND   0    0    0     0     0         63727       0     ""  0 0 0      

