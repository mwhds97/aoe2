ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  140  380  550   168    00000      19411       3     "Minarets of dust twist upwards as horse hooves strike the fractured earth.  Thousands of Seljuk Turks stream across the barrens of Anatolia to converge on the walled city of Manzikert, which was recently recaptured by the Byzantium army."     0   0   0   
2   TEXT  140  380  550   168    19411      19690       3     "The Byzantines are the heirs of Rome, and their armored cataphracts and legions of disciplined swordsmen can smash aside the light armored Turkish horse archers -- provided they can catch them.  But an unlikely turn of events has greatly improved the Turks� chances for victory."     0   0   0   
3   TEXT  200  120  450   168    39102      14767       3     "The Byzantine army is wracked by treachery and deceit from within. One day a band of mercenaries deserts the Byzantines.  On another, the army�s second in command leads a treacherous conspiracy against the commanding general."     0   0   0   
4   TEXT  200  120  450   168    53870      16451       3     "If the Turks can somehow turn the splintering factions against the Byzantine army, they may overcome a better-equipped and better-trained enemy."     0   0   0   


5   PICT  196  072  400   400   00000      39102       0     ""                                 255 255 255 
6   PICT  139  304  400   400   39102      31219       1     ""  255 255 255


15  SND   0    0    0     0     4         00000       0     "xc4s4.mp3"                        0   0   0 
16  WND   0    0    0     0     0         70321       0     ""  0 0 0      

