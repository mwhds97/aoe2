ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  180  400  450   200    00000     19990        3     "Passed down to you by Cuauhtemoc, Jaguar Warrior of Tenochtitlan.  Another omen.  The lake around the great city of Tenochtitlan rose and boiled.  It foamed until it washed against the houses of the city, sweeping many of them into the lake." 12  9  4 
2   TEXT  400  200  300   200    19990     14746        3     "I accompanied our dignitaries to meet with the new arrivals.  We journeyed towards the coast, through the lands of our enemies the Tlaxcala.  When we emerged from the forest, the strangers welcomed us, although they kept their weapons nearby." 12  9  4 
3   TEXT  230  110  400   200    34737     21641        3     "I told them that we were Aztecs, representatives of the great Montezuma.  Their leader said that his people were Spanish and he named himself Cort�z, although he seemed pleased when we referred to him as Quetzalcoatl.  Although their armor and animals seemed other-worldly, they did not seem like gods to me." 12  9  4 
4   TEXT  160  200  300   200    56378     12817        3     "We presented Cort�z gifts of finest cotton and plumes of bird feathers, but he seemed more interested in the gold ornaments.  He asked again and again if there was more gold to be found in Tenochtitlan." 12  9  4 
5   TEXT  140  400  550   200    69195     26877        3     "By now, Cort�z had advanced all the way to the lands of the Tlaxcala.  There was initial warfare made between Tlaxcala and the Spanish.  However, when Cort�z heard stories about the size of Tenochtitlan, and the numbers of our brave Aztec warriors, he suggested that the Spanish and Tlaxcala join forces and attack the Aztecs." 12  9  4 

6   PICT  268  128  400   400    00000     19990        0     "" 0 0 0
7   PICT  122  131  400   400    19990     14746        1     "" 0 0 0
8   PICT  182  301  400   400    34737     21641        2     "" 0 0 0
9   PICT  353  147  400   400    56378     12817        3     "" 0 0 0
10  PICT  098  078  400   400    69195     26877        4     "" 0 0 0







16  SND   0    0    0     0      4          0        0     "xc3s3.mp3" 0 0 0 

17  WND   0    0    0     0      0          96072        0     "" 0 0 0      
