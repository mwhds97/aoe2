ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  241  085  350   068    00000      07244       3     "It was the twilight of Moorish Spain.  The Berber army had been broken and Valencia withstood the siege."     0   0   0   
2   TEXT  180  468  450   100    07244      09938       3     "King Alfonso would not allow us to bury the Cid until he could personally attend the funeral.  When he arrived, he dispelled all thoughts of interring the Cid into the earth."     0   0   0   
3   TEXT  241  085  350   200    17182      15325       3     "Instead, the Cid�s body was preserved and placed near the altar of the church, seated on an ivory stool that he had captured from the Moors, clothed in precious silk, and holding his sword, Tizon, in his left hand."     0   0   0   
4   TEXT  256  130  350   200    32507      09052       3     "And who was left to rule in Valencia?  King Alfonso of Castille or Count Berenguer of Barcelona?  No.  Valencia is mine.  "     0   0   0   
5   TEXT  460  200  200   400    41559      19380       3     "It is I, Ximena D�az who claims rulership of my dead husband�s kingdom.  And if the Berbers return to Valencia, it is I whom they shall find commanding the soldiers of Rodrigo D�az, El Cid Campeador!"     0   0   0   


6   PICT  136  179  400   400   00000      07244       0     ""                                 255 255 255 
7   PICT  095  067  400   400   07244      09938       1     ""                                 255 255 255 
8   PICT  246  228  400   400   17182      15325       2     ""                                 255 255 255 
9   PICT  140  227  400   400   32507      09052       3     ""                                 255 255 255 
10  PICT  127  064  400   400   41559      19380       4     ""                                 255 255 255 

17  SND   0    0    0     0     4         00000       0     "xc2s6end.mp3"                        0   0   0 
18  WND   0    0    0     0     0         60940       0     ""  0 0 0      

