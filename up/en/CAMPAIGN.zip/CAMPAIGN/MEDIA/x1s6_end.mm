ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  150  110  350   200    00000      20619       3     "The city of Aquileia at the tip of the Adriatic was wiped off the face of the earth. The fugitives from that pitiful city took refuge among the islands, marshes, and lagoons at the head of the Adriatic Sea and there founded a state that afterward grew into the republic of Venice."     0   0   0   
2   TEXT  301  180  350   200    20619      03343       3     "�But what of the Pope?� I asked."     0   0   0   
3   TEXT  150  110  350   200    23962      11981       3     "�No one knows what Saint Leo said to the Hunnic King, but that very day Attila turned his army around and started back for the Hun lands on the Danube."     0   0   0   
4   TEXT  241  150  350   200    35944      11817      3     "Attila the Hun died shortly thereafter.  Since he had failed to claim Rome, he could not have Honoria, and instead brought another wife into his harem. "     0   0   0   
5   TEXT  241  130  350   200    47761      13935      3     "On his wedding night, Attila suffered a nosebleed and choked to death.  For a man who had boasted that 'where my horse has trodden, no grass grows' it was a curiously anti-climactic death."     0   0   0   
6   TEXT  241  110  350   200    61697      16166      3     "The Hunnic warriors cut their hair and gashed their faces, so that the king should be lamented, not by tears of maidens, but by the blood of warriors.  Attila�s bloody reign of conquest lasted only eight long years."     0   0   0   
7   TEXT  241  110  350   200    77863      25325      3     "Father Armand was silent for a long time.  He glanced over at the head on a stake.  �A Hunnic trophy,� he said.  �I think the man was a Visigoth.  He died at the Battle of the Catalaunian Fields.  I keep it here so that I may see it every day and remember.�  �Remember what, Father?� I asked him."     0   0   0   
8   TEXT  241  110  350   200   103189      14396       3     "The scent of a burning village.  The sound of butchery.  The way peasants would flee before the Hun riders.  The way we would ride them down.  The way it felt to conquer alongside Attila and the Huns."     0   0   0   
9   TEXT  241  110  350   068   117585      07337       3     "He leaned so close I could feel his breath.  'Sometimes..."     0   0   0   
10  TEXT  241  110  350   068   124923      01845       3     "...I miss it.'"     0   0   0

11   PICT  244  172  400   400   00000      20619       0     ""                                 255 255 255 
12   PICT  136  205  400   400   20619      03343       1     ""                                 255 255 255 
13   PICT  270  191  400   400   23962      11981       2     ""                                 255 255 255 
14   PICT  103  200  400   400   35944      11817       3     ""                                 255 255 255 
15   PICT  092  232  400   400   47761      13935       4     ""                                 255 255 255 
16   PICT  237  208  400   400   61697      16166       5     ""                                 255 255 255 
17   PICT  328  243  400   400   77863      25325       6     ""                                 255 255 255 
18   PICT  101  192  400   400  103189      14396       7     ""                                 255 255 255 
19   PICT  316  185  400   400  117585      09183       8     ""                                 255 255 255 

20  SND   0    0    0     0     4         00000       0     "xc1s6end.mp3"                        0   0   0 
21  WND   0    0    0     0     0         126769       0     ""  0 0 0      

