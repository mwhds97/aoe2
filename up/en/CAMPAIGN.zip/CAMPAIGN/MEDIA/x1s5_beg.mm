ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE


// text begins before image

1   TEXT  260  200  300   200    00000     05387        3     "�And now,� said Father Armand, �is where I entered the story.�"     12  9  4 
2   TEXT  415  220  280   250    05387     27969        3     "The battle between Hun and Roman was fought at the end of June, 451.  The Romans were commanded by Aetius, a brilliant and celebrated general who had been held hostage by Attila when he was a boy.  Aetius knew Attila and knew the Hunnic ways.  Since he had returned to the Western Empire, Aetius had done more than any man to keep Rome alive throughout the period of barbarian invasions."     12  9  4 
3   TEXT  200  400  450   200    33356     22570        3     "His army was not large enough to face Attila alone, so Aetius convinced tribes of the Alans and Visigoths to ally with him.  Even though these dubious allies had a common hatred of the Huns, it was still a remarkable achievement on Aetius' part to have drawn them into an effective military relationship."     12  9  4 
4   TEXT  200  130  450   200    55927     19652        3     "The Huns were eager for battle.  Attila�s shamans looked at the entrails of cattle and the color of sheep bones, and prophesized that the Huns would meet defeat on the Catalaunian fields.  However, they also foresaw that the commander of the opposing force would be killed."     12  9  4 
5   TEXT  200  130  450   200    75579     06433        3     "Attila must have thought this a fair trade because he brought battle to Aetius and the Goths."     12  9  4 
8   TEXT  160  200  250   200    82012     25705        3     "Before blood was drawn, Attila stood before his assembled troops clutching the sword of Mars in his fist.  He told them, �It is a right of nature to glut the soul with vengeance.  I shall hurl the first spear at the foe.  If any man can stand at rest while Attila fights, he is a dead man.�"     12  9  4 


9    PICT  145  080  400   400    05387     27969        0     "" 0 0 0
10   PICT  270  061  400   400    33356     22570        1     "" 0 0 0
11   PICT  122  322  400   400    55927     19652        2     "" 0 0 0
12   PICT  099  215  400   400    75579     06433        3     "" 0 0 0
13   PICT  259  110  400   400    82012     25705        5     "" 0 0 0











16  SND   0    0    0     0      4          00001        0     "xc1s5.mp3" 0 0 0 

17  WND   0    0    0     0      0          107763        0     "" 0 0 0      
