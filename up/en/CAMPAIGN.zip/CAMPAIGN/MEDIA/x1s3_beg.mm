ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  160  115  300   200    00000     20897        3     "By this time, the Romans had considerable experience dealing with barbarians.  They could civilize the raiders to some extent by offering them otherwise useless land on the Roman borders as a token tribute.  Before Attila, this tactic seemed to be working on the Huns, who settled on the Danube River valley."       12  9  4 
2   TEXT  130  070  550   089    20897     17925        3     "All that changed when Attila seized command.  He was much more aggressive and unpredictable than the previous Hunnic kings.  He demanded that the tributes from Rome be increased and when the Romans refused, Attila marched on the Eastern Roman Empire."       12  9  4 
3   TEXT  280  070  350   070    38823     06594        3     "He marched on the great city of Constantinople, whose double walls had never fallen."       12  9  4 
4   TEXT  300  400  300   200    45418     18041        3     "Attila was done with raiding.  Now the Huns advanced slowly, eradicating everything in their path.  The Romans would reinstate the tribute, or they would be destroyed."       12  9  4 


5   PICT  212  175  400   400    00000     20897        0     "" 0 0 0
6   PICT  172  129  400   400    20897     24520        1     "" 0 0 0
7   PICT  251  052  400   400    45418     18041        2     "" 0 0 0



16  SND   0    0    0     0      4          00001        0     "xc1s3.mp3" 0 0 0 

17  WND   0    0    0     0      0          63460        0     "" 0 0 0      
