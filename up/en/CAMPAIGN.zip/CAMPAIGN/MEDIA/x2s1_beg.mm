ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

// El Cid
// First Image had no text (church)


1   TEXT  150  085  300   200    00000     18018        3     "Enough.  You have troubled me for three blocks now, stranger.  If you agree to cease this dogged pursuit and leave me to my lamentations, then I will answer your relentless questions.  I will tell you why a dead man rides through the streets of Valencia." 0 0 0
2   TEXT  150  330  300   200    18018     15232        3     "You see that castle on the hill?  That is the home of Rodrigo D�az, whom Moor and Christian alike call 'El Cid'.  It is from the Arabic 'sayyid' which means 'lord'.  He is the greatest man who ever lived." 0 0 0
3   TEXT  390  085  300   200    33250     04365        3     "The Cid was a knight and loyal vassal of one of the old Kings of Spain." 0 0 0
4   TEXT  500  150  200   500    37616     29535        3     "When the old King died, his kingdom was partitioned between his surviving sons, Sancho and Alfonso.  King Sancho ruled Castille, a windswept barren land named for its many border castles.  The Cid continued to serve Castille, and its new king, as was his duty.  The sly King Alfonso ruled L�on, but openly plotted to become king of all of Christian Spain.  There was soon open warfare between Castille and L�on." 0 0 0
5   TEXT  340  085  380   400    67152     07926        3     "The struggle climaxed at the battle of Golpejera, where The Cid attempted to capture the wicked Alfonso." 0 0 0



6   PICT  244  180  300   200    00000     18018        0     ""12  9  4 
7   PICT  222  074  300   200    18018     15232        1     ""12  9  4 
8   PICT  172  166  300   200    33250     04365        2     ""12  9  4 
9   PICT  118  092  300   200    37616     29535        3     ""12  9  4 
10  PICT  090  090  300   200    67152     07926        4     ""12  9  4 


16  SND   0    0    0     0      4          1000        0     "xc2s1.mp3" 0 0 0 

17  WND   0    0    0     0      0          75078        0     "" 0 0 0      
