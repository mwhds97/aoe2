ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  140  120  300   200    00000     15217        3     "When my warriors had captured the shrines and defeated the Xochimilco and Tlatiluco, we made the long journey back to Tenochtitlan, laden with gifts for Emperor Montezuma: jade, feathers, and of course, prisoners." 12  9  4 
2   TEXT  250  120  350   200    15217     07073        3     "The sheer vastness of our city on the lake seemed staggering after having been in the rain forest for so many days." 12  9  4 
3   TEXT  190  120  400   200    22291     16272        3     "Emperor Montezuma lives in the most sumptuous rooms of the palace with his wives and concubines.  While we spoke, he drank frothing chocolate from a golden cup.  Musicians played their drums and flutes and masked women danced." 12  9  4 
4   TEXT  140  100  500   200    38563     17878        3     "When my uncle, Montezuma, first ascended the great pyramid many years ago to become emperor, there was a great celebration.  Yet now some question his leadership.  He sometimes makes decisions slowly, and rarely does he lead the warriors into combat." 12  9  4 
5   TEXT  360  320  300   200    56442     22731        3     "Montezuma�s priests informed us that Quetzalcoatl, the feathered serpent, would soon return to Tenochtitlan to reclaim his kingdom.  Since I helped prepare for his coming, I was given a new obsidian macana, and promoted to the rank of Jaguar Warrior.  There was more feasting and dancing that night.  The air was heavy with perfume." 12  9  4 
6   TEXT  140  120  300   200    79174     16445        3     "But I noticed as I walked down the steps of the emperor�s palace that the omen still hung heavily over the lake, spraying sparks over the midnight sky.  So says Cuauhtemoc, Jaguar Warrior of Tenochtitlan." 12  9  4 


7    PICT  207  138  400   400    00000     15217        0     "" 0 0 0
8    PICT  285  165  400   400    15217     07073        1     "" 0 0 0
9    PICT  132  240  400   400    22291     16272        2     "" 0 0 0
10   PICT  248  153  400   400    38563     17878        3     "" 0 0 0
11   PICT  132  119  400   400    56442     22731        4     "" 0 0 0
12   PICT  248  107  400   400    79174     16445        5     "" 0 0 0



16  SND   0    0    0     0      4          1000        0     "xc3s1end.mp3" 0 0 0 

17  WND   0    0    0     0      0          95619        0     "" 0 0 0      
