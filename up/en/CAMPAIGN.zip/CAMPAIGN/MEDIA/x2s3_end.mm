ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  450  200  250   400    00000      14396       3     "Motamid, Lord of Zaragoza, was a gifted leader of men, but like many of the Moors, he was also a poet and artist.  The cultural achievements of the Moors made the rest of Europe seem barbaric by comparison."     0   0   0   
2   TEXT  241  085  350   200    14396      12575       3     "As the Cid parlayed with Lord Motamid in his sumptuous palace, he feasted on meals that came floating down an indoor stream.  Motamid bestowed rich gifts on the Cid, and made him a wealthy man.  "     0   0   0   
3   TEXT  261  150  350   200    26971      08600       3     "But the Cid, ever the loyal servant of Castille, convinced Motamid to ratify a treaty, making Zaragoza part of Castille."     0   0   0   
4   TEXT  180  430  450   200    35572      23707       3     "The Cid never fought openly against King Alfonso, though he did make enemies with Count Berenguer and other Spanish lords who wanted only tributes of gold from the Moors and were not interested in making alliances with them.  Count Berenguer would remain the Cid�s enemy for many years."     0   0   0   


5   PICT  117  122  400   400   00000      14396       0     ""                                 255 255 255 
6   PICT  150  203  400   400   14396      12575       1     ""                                 255 255 255 
7   PICT  220  267  400   400   26971      08600       2     ""                                 255 255 255 
8   PICT  103  088  400   400   35572      23707       3     ""                                 255 255 255 



17  SND   0    0    0     0     4         00000       0     "xc2s3end.mp3"                        0   0   0 
18  WND   0    0    0     0     0         59280       0     ""  0 0 0      

