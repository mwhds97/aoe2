ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  450  220  200   400    00000      21733       3     "Mercenaries and Norman knights look dubiously at the ships that wobble in the black, fog-choked sea.  What man is this Duke William to put so many horses on leaky transports?  William ignores their questioning glances and stares across the channel in the direction of England. "     0   0   0   
2   TEXT  450  220  200   400    21733      14024       3     "Edward the Confessor is dead and now three men claim rulership of England. Harold the Saxon sits on the English throne and even now hastens to fortify his shores against two invasions.  "     0   0   0   
3   TEXT  190  110  450   100    35758      15826       3     "Harold Hardraade, King of Denmark and Norway, sends Vikings from the north as William invades from the south.  The outcome of this three-way conflict is as murky as the fog that shrouds the English Channel."     0   0   0   
4   TEXT  190  110  450   120    51585      23531       3     "Harold the Saxon�s huskarls are professional soldiers, not mercenaries.  William�s only chance of defeating them is to use heavy cavalry.  But to do so, he must first get all of these horses onto these unreliable boats.  The future of England is about to be decided�."     0   0   0   

5   PICT  128  098  400   400   00000      35758       0     ""                                 255 255 255 
6   PICT  111  230  400   400   35758      39357       1     ""                                 255 255 255 

15  SND   0    0    0     0     4         00000       0     "xc4s3.mp3"                        0   0   0 
16  WND   0    0    0     0     0         75116       0     ""  0 0 0      

