ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  160  080  500   130    00000      15325       3     "Alfonso needed only have mentioned that Spain was in jeopardy, and the Cid would have come!  And when the Cid did finally come to his king�s aid, the Berbers were crushed, and their leader, Yusuf, was forced to flee back to Africa."     0   0   0   
2   TEXT  211  468  430   130    15325      13003       3     "The Cid bowed to Alfonso, ready to return to his rightful place as the king�s champion.  But King Alfonso was angered that the Cid had not arrived sooner and ordered him to return to his exile."     0   0   0 
3   TEXT  241  085  350   130    28328      14233       3     "This time he seized the Cid�s wife and children.  Many long years did I rot in the dungeons of Castille."     0   0   0 

4   PICT  123  146  400   400   00000      15325       0     ""                                 255 255 255 
5   PICT  370  101  400   400   15325      13003       1     ""                                 255 255 255 
6   PICT  115  063  400   400   28328      14233       2     ""                                 255 255 255 



17  SND   0    0    0     0     4         00000       0     "xc2s4end.mp3"                        0   0   0 
18  WND   0    0    0     0     0         42562       0     ""  0 0 0      

