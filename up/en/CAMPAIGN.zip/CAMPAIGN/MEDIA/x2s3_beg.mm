ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  200  100  300   200    00000     17885        3     "King Alfonso sent his most loyal and able servant, Rodrigo D�az, the Cid, into exile with only his horse, Bavieca.  Myself and our two daughters were left at the monastery in Castille."        12  9  4 
2   TEXT  300  100  300   200    17885     10907        3     "When Rodrigo and I parted, it felt like a nail being torn from its finger.  Rodrigo rode alone into the Castillian winter."        12  9  4 
3   TEXT  270  090  300   200    28792     13550        3     "He was not alone for long.  Everywhere the Cid went, mercenaries and soldiers were eager to follow.  Soon, he had a small army of his own.  But the Cid was not content to wander the wilds of Castille forever."        12  9  4 
4   TEXT  250  170  350   200    42342     12432        3     "He needed a castle and a lord to serve.  This too, he found, in the most unlikely of places. "        12  9  4 




5   PICT  242  206  400   400    00000     17885        0     "" 0 0 0
6   PICT  122  238  400   400    17885     10907        1     "" 0 0 0
7   PICT  113  143  400   400    28792     13550        2     "" 0 0 0
8   PICT  173  267  400   400    42342     12432        3     "" 0 0 0

16  SND   0    0    0     0      4          1000        0     "xc2s3.mp3" 0 0 0 

17  WND   0    0    0     0      0          54775        0     "" 0 0 0      
