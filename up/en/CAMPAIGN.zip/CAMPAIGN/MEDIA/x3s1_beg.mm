ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  340  350  350   200    00000      24706       3     "Passed down to you by Cuauhtemoc, Eagle Warrior of Tenochtitlan.  An omen appeared above the forest, the shape of an ear of corn, but blazing like daybreak.  It seemed to bleed fire, drop by drop, like a wound in the sky.  I am a warrior, not a priest, and knew not what to make of such a sign."     12  9  4    
2   TEXT  140  105  350   200    24706      14303       3     "I consulted with the seers and magicians to see if another great war was coming, but they answered only in riddles.  �The gods want more sacrifice,� was their answer.  That was always their answer."     12  9  4    
3   TEXT  360  180  300   400    39009      13374       3     "Much of our empire of rain forests and volcanoes has been conquered in the name of sacrifice.  The magicians tell us that we must make a sacrifice every single day for the sun to continue to rise."     12  9  4    
4   TEXT  360  200  300   450    52384      16161       3     "It took the relay teams two full days to carry my message the two hundred miles to our city of Tenochtitlan.  After two more days, my uncle, Montezuma, emperor of the Aztecs, sent his reply."     12  9  4    
5   TEXT  120  105  350   200    68545      10402       3     "Montezuma�s priests foretold that the god Quetzalcoatl might soon return from his long exile.  How else to explain the omen?"     12  9  4    
6   TEXT  300  105  350   200    78947      14303       3     "Montezuma ordered my warriors to increase their efforts to consolidate the rain forest between our lands and those of our enemies. We must establish control over four shrines that are sacred to Quetzalcoatl, the feathered serpent."     12  9  4    
7   TEXT  130  105  350   200    93251      20387       3     "Because the Aztec Empire is mighty and constantly expands, we have made many enemies. We must defend these shrines from our enemies in order to prepare for Quetzalcoatl�s eventual return."     12  9  4    

8    PICT  089  085  400   400   00000      24706       0     ""                                 255 255 255 
9    PICT  286  146  400   400   24706      14303       1     ""                                 255 255 255 
10   PICT  098  186  400   400   39009      13374       2     ""                                 255 255 255 
11   PICT  112  152  400   400   52384      16161       3     ""                                 255 255 255 w
12   PICT  218  151  400   400   68545      10402       4     ""                                 255 255 255 
13   PICT  109  112  400   400   78947      14303       5     ""                                 255 255 255 
14   PICT  254  194  400   400   93251      20387       6     ""                                 255 255 255 

15  SND   0    0    0     0     4         00000       0     "xc3s1.mp3"                        0   0   0 
16  WND   0    0    0     0     0         113638       0     ""  0 0 0      

