ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  310  250  300   200    00000     15929        3     "As far as Attila was concerned, Honoria was waiting with open arms in Rome.  The very next year, partially recovered from his losses, Attila turned his attention to Italy."  12  9  4 
2   TEXT  140  070  200   200    15929     15602        3     "The Huns crossed over the Alps, and moved down the Italian peninsula, launching another great invasion that terrorized the inhabitants of the Western Roman Empire.  He meant to take Rome, and crown himself emperor."  12  9  4 
3   TEXT  390  100  300   200    31531     18066        3     "This was not the Rome of Caesar, mind you, but a withering Rome, beaten from earthquakes and barbarian wars.  And this time, there was no General Aetius to hold off the Huns� savagery."  12  9  4 


4   PICT  152  102  400   400    00000     15929        0     "" 0 0 0
5   PICT  284  096  400   400    15929     15602        2     "" 0 0 0
6   PICT  063  172  400   400    31531     18066        1     "" 0 0 0





16  SND   0    0    0     0      4          1000        0     "xc1s6.mp3" 0 0 0 

17  WND   0    0    0     0      0          49597        0     "" 0 0 0      
