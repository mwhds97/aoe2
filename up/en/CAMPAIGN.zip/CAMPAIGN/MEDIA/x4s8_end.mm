ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  190  360  450   168    00000      20526       3     "The Japanese were unable to establish a base on either China or Korea.  Therefore, all supplies and reinforcements had to come from the Japanese islands themselves.  Once Admiral Yi destroyed the Japanese navy, the samurai armies were isolated from supply, and the invasion ended."     0   0   0   
2   TEXT  241  110  350   168    20526      24764       3     "Yi Sun-shin died in the battle, but the Japanese commander, Hideyoshi, died soon after, and with him, the lust for Japanese conquest.  The possibility of a Japanese empire in eastern Asia in the 16th century died under the guns of slow, but deadly, armored Korean warships."     0   0   0   

3   PICT  120  055  400   400   00000      20526       0     ""                 255 255 255
4   PICT  305  215  400   400   20526      24764       1     ""                                255 255 255 




17  SND   0    0    0     0     4         00000       0     "xc4s8end.mp3"                        0   0   0 
18  WND   0    0    0     0     0         45290       0     ""  0 0 0      

