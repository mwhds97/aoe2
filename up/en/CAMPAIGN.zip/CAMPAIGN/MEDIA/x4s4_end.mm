ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  260  115  350   130    00000      18898       3     "As long as the sun was in the sky, the Byzantine army could fight the Turks back towards their camp.  But when dusk settled over Anatolia, the Turks could harass the ponderous Byzantine cavalry as it withdrew to Manzikert."     0   0   0   
2   TEXT  260  115  350   130    18898      10916       3     "When they could stand no more of this torment, the Byzantine flanks collapsed into a full rout and the Turkish horse archers pounced for a quick kill."     0   0   0   
3   TEXT  480  200  220   400    29814      20262       3     "The Battle of Manzikert was not lost due to the poor performance of soldiers or commanders, but through Byzantine treachery. Deceit from within the armies disrupted the chain of command, as factions feuding for control of the throne in Constantinople betrayed their armies at the front."     0   0   0   
4   TEXT  480  200  220   400    50076      24296       3     "A much-weakened Byzantium was then forced to call to the rest of the Christian West for help, leading to the Crusades.  The Byzantine Empire lingered for another four centuries but in only a shadow of its former glory."     0   0   0   



5   PICT  052  217  400   400   00000      29814       0     ""                                 255 255 255 
6   PICT  114  106  400   400   29814      44559       1     ""                                 255 255 255 




17  SND   0    0    0     0     4         00000       0     "xc4s4end.mp3"                        0   0   0 
18  WND   0    0    0     0     0         74373       0     ""  0 0 0      

