ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  150  080  520   100    00000      19876       3     "The steady splashing, as the oars of 200 ships strike the water, drowns out all other sound.  The most powerful fleet ever assembled by Don Juan of Austria and his allies in Venice sails under the burning light of dawn towards a final encounter with the Ottoman Turks."     0   0   0   
2   TEXT  150  080  520   080    19876      14396       3     "The Turkish army has greatly expanded its empire, adding North Africa and Mesopotamia to the Turkish holdings in Anatolia, but has finally been turned back by a staunch defense of Hungary."     0   0   0  
3   TEXT  150  080  520   100    34272      10309       3     "Undaunted, the Turks turned their attention to the Mediterranean, where they intended to break the Christian naval powers of Venice and Spain."     0   0   0
4   TEXT  200  370  450   168    44582      32194       3     "Now 230 rowed galleys and six heavy galleases lumber into the Bay of Lepanto to meet the 270 galleys of the Turkish fleet.  The ships draw up with scarcely five miles separating the distance between them.  A storm of arrows darkens the sky, and the drone of splashing oars is finally drowned out by the thunder of cannon."     0   0   0  

5   PICT  171  164  400   400   00000      44582       0     ""                                 255 255 255 
6   PICT  168  079  400   400   44582      32194       1     ""               255 255 255

15  SND   0    0    0     0     4         00000       0     "xc4s6.mp3"                        0   0   0 
16  WND   0    0    0     0     0         76776       0     ""  0 0 0      

