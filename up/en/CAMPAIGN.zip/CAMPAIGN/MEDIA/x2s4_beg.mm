ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE


1   TEXT  250  085  350   200    00000     13374        3     "King Alfonso watched with alarm as the combined Christian - Moorish forces of the Cid gained power and prestige.  Finally, he could stand it no longer, and sent his own army against Motamid�s Moors at Zaragoza."    12  9  4 
2   TEXT  160  200  300   200    13374     11365        3     "As much as he would have liked to come to the assistance of his friend Motamid, the Cid could not draw steel against King Alfonso, as he was still the Cid�s rightful lord."    12  9  4 
3   TEXT  170  085  410   200    24740     12006        3     "Since the Cid could not assist him, Motamid was forced to seek help elsewhere.  When he contacted the Berbers who lived beyond the sea in Gibraltar, however, he received more than he bargained for."    12  9  4 
4   TEXT  250  085  350   200    36747     06349        3     "These veiled religious zealots waged a continuous jihad across the barren dunes of the Sahara."    12  9  4 
5   TEXT  155  470  510   200    43096     15986        3     "Their leader, the fanatical Yusuf who never showed his face, immediately prepared to cross the ocean into Spain with thousands of men and camels.  King Alfonso�s army was certain to crumble beneath this new wave of invaders. "    12  9  4 

6   PICT  172  302  400   400    00000     13374        0     "" 0 0 0
7   PICT  161  253  400   400    13374     11365        1     "" 0 0 0
8   PICT  206  117  400   400    24740     12006        2     "" 0 0 0
9   PICT  110  189  400   400    36747     06349        3     "" 0 0 0
10  PICT  109  070  400   400    43096     15986        4     "" 0 0 0



16  SND   0    0    0     0      4          1000        0     "xc2s4.mp3" 0 0 0 

17  WND   0    0    0     0      0          59083        0     "" 0 0 0      
