ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  180  110  450   168    00000      22886       3     "Not so long ago, some five hundred thousand people called Tenochtitlan home.  It is difficult to recall that this smoking ruin was once an endless city.  Yet, we will rebuild.  We created this island upon which our city and temples stand, and we can do it once more."     12 9 4   
2   TEXT  241  120  350   268    22886      31448       3     "The Aztec Empire has endured its greatest challenge.  Yet, more Spanish may come in the future.  I am not certain there is a place for us in this new world.  I could ask the gods for a hint of the future, but no doubt that would lead to more sacrifice and I think there has been enough death for now.  My people composed a poem to commemorate this great war that we have survived, and yet perhaps still not won:"     12 9 4   
3   TEXT  241  120  350   168    54334      17414       3     "Broken spears lie in the roads. We have torn our hair in our grief.  The houses are roofless now, and their walls are red with blood�So says Cuauhtemoc, Emperor of Tenochtitlan."     12 9 4   


4   PICT  230  178  400   400   00000      22886       0     ""                                 255 255 255 
5   PICT  095  193  400   400   22886      31448       1     ""                                 255 255 255 
6   PICT  119  114  400   400   54334      17414       2     ""                                 255 255 255 



17  SND   0    0    0     0     4         00000       0     "xc3s6end.mp3"                        0   0   0 
18  WND   0    0    0     0     0         71749       0     ""  0 0 0      

