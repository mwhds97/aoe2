ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  360  250  300   200    00000     14210        3     "Passed down to you by Cuauhtemoc, prisoner of Tenochtitlan.  The next omen we did not see, but heard the voice of a weeping woman who cried in the night that she could not hide her children." 12  9  4 
2   TEXT  160  250  300   200    14210     23684        3     "Indecision plagued Emperor Montezuma.  Was this man Quetzalcoatl, or was he just a man?  As the emperor brooded, the citizens grew restless.  Cort�z kept a close watch on the emperor, and soon Montezuma became a prisoner in his own palace.  Thus did the Spanish take Tenochtitlan without a siege." 12  9  4 
3   TEXT  140  180  200   300    37894     10031        3     "The Spanish collected all of the gold they could find.  They were not interested in our art or ornaments, but merely melted down the gold for return to Spain." 12  9  4 
4   TEXT  250  200  300   200    47925     07801        3     "They also outlawed any further sacrifice to the gods.  When the priests protested, they were killed." 12  9  4 
5   TEXT  290  180  300   200    55727     08452        3     "The citizens and warriors of Tenochtitlan were enraged.  We knew, even if our emperor did not, that these men were not gods." 12  9  4 
6   TEXT  360  200  300   200    64179     16550        3     "Riots broke out in the marketplaces and at the palace.  When Montezuma himself appeared on the walls urging the Aztecs to be at peace, the people threw stones at him.  It was time to remove these so-called gods from Tenochtitlan!" 12  9  4 


7    PICT  091  175  400   400    00000     14210        0     "" 0 0 0
8    PICT  434  142  400   400    14210     23684        1     "" 0 0 0
9    PICT  310  119  400   400    37894     10031        2     "" 0 0 0
10   PICT  128  331  400   400    47925     07801        3     "" 0 0 0
11   PICT  134  252  400   400    55727     08452        4     "" 0 0 0
12   PICT  119  160  400   400    64179     16550        5     "" 0 0 0





16  SND   0    0    0     0      4          1000        0     "xc3s4.mp3" 0 0 0 

17  WND   0    0    0     0      0          80729        0     "" 0 0 0      
