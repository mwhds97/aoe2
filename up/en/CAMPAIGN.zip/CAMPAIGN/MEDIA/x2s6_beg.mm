ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE




1   TEXT  250  085  350   200    00000     18761        3     "We were trapped and alone in our kingdom of Valencia.  The Cid immediately sent out messages for potential allies, but there were few to be found.  The Christian kingdom of Aragon was too far away, and King Alfonso of Castille seemed in no hurry to come to the Cid�s defense." 12  9  4 2   
2   TEXT  420  085  250   400    18761     11331        3     "Even the Cid�s old ally, Motamid the Moor, was of no avail.  Yusuf had sent him into exile in the Sahara Desert, where he spent the rest of his sad days composing poetry." 12  9  4 
3   TEXT  140  220  250   400    30093     14117        3     "The Berbers rode around the city for ten days and nights, shrieking and banging their weapons on shields made of hippopotamus hide.  But the Cid comforted his troops, prayed and planned a counterattack." 12  9  4 
4   TEXT  400  085  250   200    44210     18204        3     "And then the unthinkable happened.  During a brilliant surprise attack to capture gold and horses from the Berbers, Rodrigo D�az, my Cid, was shot by a stray arrow.  The surprise attack became a rout, and the Cid�s men barely made it back to the castle with his broken body." 12  9  4 
5   TEXT  360  100  300   200    62415     10959        3     "Rodrigo and I knew he would not last the night.  But we also knew that without their Cid to lead them, the soldiers of Valencia would never have the strength to stand against the Berbers.  " 12  9  4 
6   TEXT  160  085  300   200    73375     12353        3     "So it was that even as he breathed his last breath, I strapped my husband onto his horse, Bavieca, and placed his sword, Tizon, in his hand. Bavieca stood out above the city of Valencia." 12  9  4 
7   TEXT  420  085  250   400    85728     08010        3     "My one hope was that the men would not realize the charade -- realize that their Cid was already dead." 12  9  4 


8    PICT  109  257  400   400    00000     18761        0     "" 0 0 0
9    PICT  118  231  400   400    18761     11331        1     "" 0 0 0
10   PICT  392  099  400   400    30093     14117        2     "" 0 0 0
11   PICT  117  242  400   400    44210     18204        3     "" 0 0 0
12   PICT  118  111  400   400    62415     10959        4     "" 0 0 0
13   PICT  326  194  400   400    73375     12353        5     "" 0 0 0
14   PICT  145  062  400   400    85728     08010        6     "" 0 0 0


16  SND   0    0    0     0      4          1000        0     "xc2s6.mp3" 0 0 0 

17  WND   0    0    0     0      0          93738        0     "" 0 0 0      
