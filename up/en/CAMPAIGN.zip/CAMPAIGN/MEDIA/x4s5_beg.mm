ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  490  220  200   300    00000      19876       3     "The rains come again, until there is nothing left of road or wood or field, nothing in the entire world but mud. The exhausted English soldiers hoist their longbows over their heads, trying to protect the precious yew wood from the water."     0   0   0   
2   TEXT  490  220  200   300    19876      14489       3     "The empty wagons can scarcely roll forward, even though all of the supplies have long been eaten.  From the rear terrifying hoof beats resound.  The French knights have come."     0   0   0   
3   TEXT  330  410  350   200    34365      13746       3     "The English have been in a slow retreat ever since the debacle at Harfleur, where King Henry the Fifth�s glorious siege dragged on and on, costing the lives of 3000 Englishmen."     0   0   0   
4   TEXT  330  410  350   200    48111      14117       3     "Now Henry has all but abandoned his dream of establishing his hereditary claim to the French crown.  Like his men, he only wants to reach Calais and the ships that will return them home to England."     0   0   0   
5   TEXT  330  410  350   200    62229      16948       3     "But on the road back to Calais, the French army overtakes Henry.  Knowing that the English are fatigued, starving and outnumbered three to one, the French have no interest in negotiation.  The English make their stand on a wooded hilltop. "     0   0   0   
6   TEXT  330  410  350   200    79177      06271       3     "The archers plant stakes in the ground to offer some barrier against the deadly French cavalry."     0   0   0   
7   TEXT  330  410  350   200    85449      17473       3     "Henry�s only hope is that his lightly-armored infantry prove more nimble than the impetuous French knights and that the range of his archers can even the odds before the French horses are upon them."     0   0   0   


8   PICT  113  119  400   400   00000      34365       0     ""                                 255 255 255 
9   PICT  112  070  400   400   34365      68556       1     ""                                 255 255 255 




15  SND   0    0    0     0     4         00000       0     "xc4s5.mp3"                        0   0   0 
16  WND   0    0    0     0     0         102922       0     ""  0 0 0      

