ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  200  120  450   150    00000      16997       3     "The first messengers to arrive in Tenochtitlan told of mountains or towers that floated on the sea.  Each story told to Montezuma was more fantastic than the last: They could fire stone balls, shooting sparks and raining fire that could crack open weapons."     12  9  4    
2   TEXT  200  120  450   150    16997      16998       3     "Huge deer with no antlers carried these gods on their backs.  Their swords were iron, their bows were iron, their shields were iron, their clothes were iron.  Surely this was the return of Quetzalcoatl!"     12  9  4    
3   TEXT  340  120  350   168    33994      17460       3     "Montezuma heard these reports with growing alarm, as he shifted nervously on the icpalli, his legless throne.  He ordered expensive gifts to be sent to the new arrivals, in the hopes that Quetzalcoatl would spare Montezuma, when the feathered serpent came to Tenochtitlan."     12  9  4    
4   TEXT  360  220  350   168    51455      21350       3     "�He has come back,� Montezuma whispered to me.  �He seeks his place on the throne, for that is what he promised when he departed.�  I held my weapons tightly but said nothing.  How could I challenge the word of our emperor?  So says Cuauhtemoc, Jaguar Warrior of Tenochtitlan."     12  9  4    

5   PICT  169  228  400   400   00000      16997       0     ""                                 255 255 255 
6   PICT  259  203  400   400   16997      16998       1     ""                                 255 255 255 
7   PICT  116  216  400   400   33994      17460       2     ""                                 255 255 255 
8   PICT  132  102  400   400   51455      21350       3     ""                                 255 255 255 




17  SND   0    0    0     0     4         00000       0     "xc3s2end.mp3"                        0   0   0 
18  WND   0    0    0     0     0         72806       0     ""  0 0 0      

